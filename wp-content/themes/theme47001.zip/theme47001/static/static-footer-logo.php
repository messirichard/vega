<?php /* Static Name: Footer text */ ?>
<a href="<?php echo home_url(); ?>/"><img src="<?php echo of_get_option('footer_logo_url'); ?>" alt=""></a>